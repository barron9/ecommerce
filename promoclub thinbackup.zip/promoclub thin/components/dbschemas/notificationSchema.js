
const notificationSchema = {
	name: 'Notifications',
	properties: {
		id: 'string',
		notification: 'string',
		time: 'string',
	},

}
export default notificationSchema