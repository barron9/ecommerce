import React, { Component } from 'react';


export default class SettingsScreen extends React.Component {
	constructor(props) {
		super(props);
		this.state = { loading: false };
	}
	static navigationOptions = {
		title: '',
		header: null,
	};
	componentDidMount() {}

	render() {}
}